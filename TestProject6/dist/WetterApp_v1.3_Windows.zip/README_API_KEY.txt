Bitte erstelle eine Datei namens ".env" in diesem Ordner und füge deinen Key ein:
OPENWEATHER_API_KEY=dein_key_hier